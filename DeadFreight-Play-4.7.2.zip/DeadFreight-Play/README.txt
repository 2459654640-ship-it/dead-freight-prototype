DEAD FREIGHT - Godot 4.7.2 pre-imported play package

1. Fully extract this ZIP into a new writable folder.
2. Drag your existing Godot 4.7.2 console EXE onto Play_Windows.cmd.
   Or double-click Play_Windows.cmd and paste the full Godot EXE path.
3. Click DEPLOY in the game menu.

No editor import is needed. This is a pre-imported game PCK, not the editable source.
Use Godot 4.7.2 (standard console build recommended); the engine EXE is not included.
If it still closes, send logs/game-console.log, logs/game-engine.log and logs/engine-version.txt.
Windows-specific operation still needs confirmation on your machine.

WASD move; mouse look; LMB fire; RMB aim; R reload; 4 heal; hold F search;
Tab inventory; M map; Esc pause; Shift sprint; Ctrl crouch; Space jump.

Artist attribution is in ATTRIBUTION.md.
